GitHub Pages 上传说明

1. 打开 github.com，登录账号。
2. 点击右上角 + 号，选择 New repository。
3. Repository name 可以填写：h5-winter-olympics
4. 选择 Public，然后点击 Create repository。
5. 点击 Add file -> Upload files。
6. 把本压缩包里的 index.html 上传进去。
7. 点击 Commit changes。
8. 进入仓库 Settings -> Pages。
9. Source 选择 Deploy from a branch。
10. Branch 选择 main，目录选择 /root，然后点击 Save。
11. 等 1-3 分钟，刷新 Pages 页面，会出现一个链接：
    https://你的GitHub用户名.github.io/h5-winter-olympics/

注意：
- 文件名必须叫 index.html，这样 GitHub Pages 才能直接打开。
- 仓库必须是 Public，免费账号才能直接用 GitHub Pages 发布。
